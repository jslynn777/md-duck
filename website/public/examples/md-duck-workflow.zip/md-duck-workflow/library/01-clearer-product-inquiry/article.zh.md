<!-- block:title -->

# 写一封信息清楚的产品询价

<!-- block:intro -->

一封有用的询价，应当提供足够的信息，让供应商能回答你的下一步问题。先写一段简短的消息，再站在对方的角度读一遍。

<!-- block:request-heading -->

## 让询价要求更具体

<!-- block:request-details -->

告诉供应商你需要什么，并请对方报价。

<!-- block:unknown-heading -->

## 不确定的信息先留空

<!-- block:unknown-details -->

尚未确认的信息先用占位符。请供应商说明有哪些选项，不要编造规格，也不要承诺尚未确认的交付日期。

<!-- block:check-heading -->

## 发送之前再读一遍

<!-- block:check-details -->

检查消息是否具体、事实是否由你确认，以及收件人能否看清你希望对方回答什么。
