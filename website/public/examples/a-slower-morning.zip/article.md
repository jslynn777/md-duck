<!-- block:title -->
# A slower morning

<!-- block:intro -->
On Saturday, I leave my phone at home and walk to the small café around the corner. There is no plan for the next hour. Just a cup of coffee, a book, and a seat by the window.

<!-- block:notice-title -->
## Notice the small things

<!-- block:notice -->
The first sip is still too hot. Outside, a cyclist waits for the light to change. Someone holds the door for a stranger. When I slow down, an ordinary morning has more to offer than I expected.

<!-- block:read -->
I read a few pages and underline a sentence I want to remember. Reading slowly gives me time to connect the words with my own experience.

<!-- block:keep-title -->
## Keep a little space

<!-- block:keep -->
A quiet hour does not need to be productive. Sometimes, making room for a small pleasure is enough.
