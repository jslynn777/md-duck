# MD Duck 空间示例 / Spaces examples

这是一套可自由试用的公开演示文章。解压到你打算长期保留的位置，再用 MD Duck 打开。本包没有个人文章、批注记录、AI 密钥或应用设置。

This package contains public demonstration articles. Extract it to a location you want to keep, then open it in MD Duck. It contains no private articles, review history, AI keys or application settings.

## 中文：先体验三种整理方式

| 文件夹 | 建议空间名称 | 体验内容 |
| --- | --- | --- |
| `Daily Drafts` | 日常草稿 | 三篇独立 Markdown，直接放在同一目录，适合随手记录。 |
| `Series Guides` | 系列指南 | 按顺序编号的文章文件夹；第一篇包含英文、中文译文和自己的素材图。 |
| `Bilingual Review` | 双语审阅 | 一篇丝带示例，原文、中文译文与 `assets/` 图片放在一起。 |

### beta.10：添加三个空间

1. 解压 ZIP，保留上述三个文件夹及里面的结构。
2. 点击阅读器右上角的空间入口，再点“添加文件夹”。
3. 分别添加 `Daily Drafts`、`Series Guides`、`Bilingual Review`，在“管理空间”里按上表重命名。
4. 通过右上角列表切换。每个空间保留自己的阅读文章与位置；在“管理空间”中可以看到三个入口。

请分别添加这三个子文件夹，不要同时把外层 `md-duck-spaces` 也添加为空间，避免目录重叠。空间名称只影响界面显示，不会重命名你的本地文件夹。

### 使用 beta.7

beta.7 可以正常读取这些 Markdown、译文和图片，但没有空间切换功能。使用“打开文件夹”一次打开其中一个目录，需要换一类文章时再打开另一个。空间切换从 beta.10 提供，beta.7 没有这些按钮。

### 试一次完整的审阅

打开 `Series Guides/01-writing-workflow/article.md`，先读原文，再切换中文或对照。把想改的一段复制给你使用的 AI，例如：

> 请把“Read first”这一节写得更具体，补一个修改前后的例子，同步更新同目录的中文译文。保留其他段落、图片相对路径和已有 block 标记。能访问本地文件时保存回原文件；不能访问时请给我可手动保存的内容。

如果使用支持空间功能的版本，可以复制“其他 AI 的空间说明”来告诉 AI 当前目录和目标文章。本示例不包含固定的空间标识或本机打开链接；这些信息由你自己的 MD Duck 生成。

AI 保存后回到 MD Duck 检查文章。是否接受内容、何时发布，由你决定。MD Duck 直接读取本地文件，文件不需要先上传或导入专有格式。

## English: try three ways to organize your writing

| Folder | Suggested space name | What to try |
| --- | --- | --- |
| `Daily Drafts` | Daily drafts | Three standalone Markdown files in one folder, for everyday notes. |
| `Series Guides` | Series guides | Numbered article folders; the first article includes an English original, a Chinese translation and its own image. |
| `Bilingual Review` | Bilingual review | A ribbon example with the original, Chinese translation and an `assets/` image kept together. |

### Beta.10: add three spaces

1. Extract the ZIP and keep the three folder structures intact.
2. Open the space control at the top right of the reader and choose **Add folder**.
3. Add `Daily Drafts`, `Series Guides` and `Bilingual Review` separately. Use **Manage spaces** to give each a clear display name.
4. Switch between them from the top-right list. Each space keeps its own article and reading position; **Manage spaces** shows all three entries.

Add the three child folders separately. Do not also add their outer `md-duck-spaces` folder: the roots would overlap. Renaming a space changes its display name, not its local folder name.

### Using beta.7

beta.7 can read these Markdown files, translations and images, but does not provide space switching. Use **Open folder** to open one example folder at a time, then open another when needed. Space switching is available in beta.10; those controls are not included in beta.7.

### Try a complete review

Open `Series Guides/01-writing-workflow/article.md`. Read the original, then switch to Chinese or the bilingual view. Copy a paragraph into your preferred AI conversation with a request such as:

> Make the “Read first” section more specific with a before-and-after example, and update the Chinese translation in the same folder. Preserve the other sections, relative image paths and existing block markers. If you can access the local files, save to the original files; otherwise provide text I can save manually.

In a version that supports spaces, **Instructions for other AI** supplies the current folder and article. This download deliberately contains no fixed space IDs or machine-specific open links: your own MD Duck generates those.

After the AI saves, return to MD Duck to review the article. You decide whether to accept the content and when to publish it. MD Duck reads the local files directly; no proprietary import or article upload is required.

## 文件约定 / File conventions

- `article.md`：原文 / original article.
- `article.zh.md`：同目录的中文译文 / Chinese companion in the same folder.
- `assets/`：该篇文章的素材图，使用相对路径 / article images, referenced with relative paths.
- `<!-- block:... -->`：保留已有标记，便于持续审阅 / preserve existing markers for continuing review.

示例来源：日常草稿、写作指南和流程插图为本项目的原创公开演示；丝带文章与 `bow.png` 来自 MD Duck 仓库已有公开示例。包内没有 `.review/`、`.mdduck/`、用户 profile 或应用配置。

Sources: the daily drafts, writing guides and workflow illustration are original public examples for this project. The ribbon article and `bow.png` come from the existing public examples in the MD Duck repository. No `.review/`, `.mdduck/`, user profile or application configuration is included.
